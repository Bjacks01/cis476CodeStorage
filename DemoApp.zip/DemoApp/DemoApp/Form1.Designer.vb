﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        btnSubmit = New Button()
        tbItem = New TextBox()
        lbReq = New ListBox()
        Label1 = New Label()
        Label2 = New Label()
        btnClear = New Button()
        cbItem = New ComboBox()
        Label3 = New Label()
        SuspendLayout()
        ' 
        ' btnSubmit
        ' 
        btnSubmit.BackColor = Color.FromArgb(CByte(128), CByte(128), CByte(255))
        btnSubmit.ForeColor = Color.White
        btnSubmit.Location = New Point(271, 44)
        btnSubmit.Name = "btnSubmit"
        btnSubmit.Size = New Size(75, 27)
        btnSubmit.TabIndex = 0
        btnSubmit.Text = "Add"
        btnSubmit.UseVisualStyleBackColor = False
        ' 
        ' tbItem
        ' 
        tbItem.Location = New Point(56, 44)
        tbItem.Name = "tbItem"
        tbItem.Size = New Size(209, 23)
        tbItem.TabIndex = 1
        ' 
        ' lbReq
        ' 
        lbReq.FormattingEnabled = True
        lbReq.ItemHeight = 15
        lbReq.Location = New Point(499, 166)
        lbReq.Name = "lbReq"
        lbReq.Size = New Size(209, 169)
        lbReq.TabIndex = 2
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(499, 148)
        Label1.Name = "Label1"
        Label1.Size = New Size(167, 15)
        Label1.TabIndex = 3
        Label1.Text = "Non-Functional Requirements"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(56, 26)
        Label2.Name = "Label2"
        Label2.Size = New Size(150, 15)
        Label2.TabIndex = 4
        Label2.Text = "Add New Quality Attribute:"
        ' 
        ' btnClear
        ' 
        btnClear.Location = New Point(633, 341)
        btnClear.Name = "btnClear"
        btnClear.Size = New Size(75, 23)
        btnClear.TabIndex = 5
        btnClear.Text = "Clear List"
        btnClear.UseVisualStyleBackColor = True
        ' 
        ' cbItem
        ' 
        cbItem.FormattingEnabled = True
        cbItem.Items.AddRange(New Object() {"Security", "Availability", "Deployability", "Integrability", "Energy Efficiency"})
        cbItem.Location = New Point(56, 101)
        cbItem.Name = "cbItem"
        cbItem.Size = New Size(209, 23)
        cbItem.TabIndex = 6
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(56, 83)
        Label3.Name = "Label3"
        Label3.Size = New Size(120, 15)
        Label3.TabIndex = 7
        Label3.Text = "Choose QA Required:"
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(Label3)
        Controls.Add(cbItem)
        Controls.Add(btnClear)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(lbReq)
        Controls.Add(tbItem)
        Controls.Add(btnSubmit)
        Name = "Form1"
        Text = "Form1"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents btnSubmit As Button
    Friend WithEvents tbItem As TextBox
    Friend WithEvents lbReq As ListBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents btnClear As Button
    Friend WithEvents cbItem As ComboBox
    Friend WithEvents Label3 As Label

End Class

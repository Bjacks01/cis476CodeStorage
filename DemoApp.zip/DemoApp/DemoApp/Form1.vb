﻿Public Class Form1
    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click

        Dim item As String
        item = tbItem.Text
        Dim item2 As String
        item2 = cbItem.Text

        cbItem.Items.Add(item)

        'MsgBox(item)

        'add text to list
        'lbReq.Items.Add(item2)


    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        tbItem.Text = ""
        cbItem.Text = ""
        lbReq.Items.Clear()
    End Sub

    Private Sub cbItem_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbItem.SelectedIndexChanged
        lbReq.Items.Add(cbItem.Text)
    End Sub
End Class
